// Shared timeline for picture (index.html) and sound (audio.py).
// All times in seconds. Edit here, re-render both.
window.CUES = {
  "duration": 25.0,
  "fps": 30,
  "bpm": 100,
  "musicDownbeat": 10.0,

  "captionA": [0.7, 3.15],
  "captionB": [3.85, 6.75],
  "layersSplit": [3.4, 3.75, 4.1],
  "riser": [6.2, 7.0],
  "sweep": [7.0, 8.15],
  "ignite": 7.62,
  "lift": [8.45, 9.9],
  "titleIn": 10.0,
  "titleToLockup": [12.0, 12.8],

  "scanType": [12.85, 13.4],
  "scanLines": [13.6, 13.74, 14.0, 14.25, 14.45, 14.65, 14.95, 15.15, 15.35],
  "scanAccents": [14.0, 14.95],
  "connector": [14.3, 16.3],
  "captionC": [13.8, 16.3],

  "stampType": [16.3, 16.75],
  "stampLines": [16.95, 17.1],
  "stamps": [16.95, 17.07, 17.19, 17.31],
  "cardShift": 17.55,
  "cardNew": 17.9,
  "verifyType": [18.15, 18.6],
  "verifyLines": [18.8, 18.98, 19.04, 19.18, 19.34, 19.5, 19.64, 19.78],
  "verifyAccents": [18.98, 19.34, 19.64],
  "captionD": [17.0, 20.3],

  "outro": 20.3,
  "logoHit": 20.8,
  "endText": [21.0, 21.18, 21.36]
};
