# NATION Guard — launch film (source)

25 s · 1920×1080 · 30 fps · 48 kHz stereo. Everything is code, so every frame and every sound can be re-timed and re-rendered.

## Concept — "What the agent reads"
Agent instruction files are drawn as a stack of layers. In the cream world (what a person sees), line 5 of `AGENTS.md`
is blank. A lime scan line sweeps across the frame. Behind it the world turns black (Guard's view), and the hidden
HTML comment lights up, lifts off the page, and comes into focus. Guard is introduced. A thin line connects that
fragment to the real `nation-guard scan` finding (`AGENTS.md:5`). The same stack then gets a lime baseline outline,
one card drifts out of its outline, a new `.mcp.json` drops in, and `nation-guard verify` flags it.
The film ends on the NATION logo.

## Files
| file | what |
|---|---|
| `cues.js` | **The single timeline.** Picture and sound both read it. Change a time here and re-render both. |
| `index.html` | The scene: 3D camera, layers, depth of field, sweep, captions, terminal, ending. `window.render(t)` draws time `t`. |
| `audio.py` | Original score and sound design, synthesised in numpy. Every accent comes from `cues.js`. |
| `render.mjs` | Headless Chromium frame renderer (Playwright) piped to ffmpeg. |
| `build.sh` | Full build: audio, then picture, then mux and loudness-normalise to -16 LUFS. |
| `verified-output.txt` | The real CLI transcript (nation-guard 0.1.0) that the terminal text comes from. |
| `assets/` | NATION logo and column (from `nation-app/public/brand`), plus the film-grain tile. |

## Build
```bash
npm i                      # @fontsource/ibm-plex-sans, @fontsource/ibm-plex-mono, playwright-core
./build.sh                 # -> out/nation-guard-launch.mp4
node render.mjs stills 1,7.6,15   # quick stills for checking a look
```
Open `index.html` in Chrome and run `render(12.5)` in the console to scrub to any moment.

## Editing notes
- **Camera:** `CAM` keyframes in `index.html` (`[time, value, ease]` per axis). Depth of field is calculated from `focusPoint()` and `aperture()`.
- **Copy:** captions are in `CAPS`. A `*` before a word sets its accent colour. The terminal lines are in `TERM`. Keep them verbatim from `verified-output.txt`.
- **Brand tokens:** CSS `:root` (cream `#F1ECE1`, ink `#0A0C0B`, lime `#CDFFA7`) and IBM Plex Sans / Mono, as used in nation-app.
- **Honesty:** the terminal output is abridged (description lines and the absolute path are left out), but no line is altered.
  The film labels Guard as experimental and says it detects *known* patterns.
