#!/usr/bin/env bash
# Full build: score -> picture (4 parallel chunks) -> concat -> mux (loudness-normalised to -16 LUFS, -1 dBTP)
set -e
cd "$(dirname "$0")"
python3 audio.py
CHUNKS=("0 6.5" "6.5 13" "13 19" "19 25")
for r in "${CHUNKS[@]}"; do set -- $r; node render.mjs video 30 $1 $2 & done; wait
: > out/list.txt; for r in "${CHUNKS[@]}"; do set -- $r; echo "file 'picture_$1_$2.mp4'" >> out/list.txt; done
ffmpeg -y -loglevel error -f concat -safe 0 -i out/list.txt -c copy out/picture.mp4
ffmpeg -y -loglevel error -i out/picture.mp4 -i out/audio.wav \
  -af "loudnorm=I=-16:TP=-1.0:LRA=11" -ar 48000 \
  -c:v copy -c:a aac -b:a 320k -movflags +faststart -shortest out/nation-guard-launch.mp4
echo "done: out/nation-guard-launch.mp4"
