"""Original score + sound design for the NATION Guard launch film.
Every accent is placed from cues.js, so picture and sound share one timeline.
    python3 audio.py  ->  out/audio.wav (48 kHz stereo)
"""
import json, re, numpy as np
from scipy.signal import fftconvolve, butter, sosfilt

SR = 48000
C = json.loads(re.search(r'=\s*(\{.*\})', open('cues.js').read(), re.S).group(1))
DUR = C['duration'] + 0.0
N = int(DUR * SR)
rng = np.random.default_rng(23)

dry = np.zeros((N, 2)); wet = np.zeros((N, 2))   # wet = reverb send

def hz(n):  # note name -> Hz
    names = {'C':0,'C#':1,'D':2,'D#':3,'E':4,'F':5,'F#':6,'G':7,'G#':8,'A':9,'A#':10,'B':11}
    m = re.match(r'([A-G]#?)(-?\d)', n); return 440 * 2 ** ((names[m[1]] + 12 * (int(m[2]) + 1) - 69) / 12)

def put(sig, t, gain=1.0, pan=0.0, send=0.3):
    if sig.ndim == 1:
        l = np.cos((pan + 1) * np.pi / 4); r = np.sin((pan + 1) * np.pi / 4)
        sig = np.stack([sig * l, sig * r], 1) * np.sqrt(2)
    i = int(t * SR); j = min(N, i + len(sig))
    if i >= N or j <= 0: return
    s = sig[max(0, -i): j - i] * gain; i = max(0, i)
    dry[i:j] += s; wet[i:j] += s * send

def env(n, a, d, curve=4.0):
    t = np.arange(n) / SR
    e = np.minimum(1, t / max(a, 1e-4)) * np.exp(-curve * np.maximum(0, t - a) / max(d, 1e-4))
    return e

def lp(x, f, order=2):
    return sosfilt(butter(order, min(f, SR / 2 * 0.95) / (SR / 2), 'low', output='sos'), x, axis=0)
def hp(x, f, order=2):
    return sosfilt(butter(order, f / (SR / 2), 'high', output='sos'), x, axis=0)
def bp(x, lo, hi):
    return sosfilt(butter(2, [lo / (SR / 2), hi / (SR / 2)], 'band', output='sos'), x, axis=0)

# ---------------- instruments ----------------
def pad(notes, dur, att=1.8, rel=1.8, bright=1800):
    n = int((dur + rel) * SR); t = np.arange(n) / SR; out = np.zeros((n, 2))
    for k, nt in enumerate(notes):
        f = hz(nt)
        for side, det in ((0, -0.07), (1, 0.07)):
            ff = f * 2 ** (det / 12)
            w = np.sin(2 * np.pi * ff * t + 0.6 * np.sin(2 * np.pi * ff * 2 * t) * 0.3)
            w += 0.35 * np.sin(2 * np.pi * ff * 2 * t + k) + 0.12 * np.sin(2 * np.pi * ff * 3 * t)
            out[:, side] += w * (1 + 0.15 * np.sin(2 * np.pi * (0.13 + 0.03 * k) * t + k))
    e = np.minimum(1, t / att) * np.clip((dur + rel - t) / rel, 0, 1) ** 1.5
    out *= e[:, None] / len(notes)
    return lp(out, bright)

def pluck(note, dur=0.9, bright=0.5):
    f = hz(note); n = int(dur * SR); p = int(SR / f)
    buf = rng.uniform(-1, 1, p) * 0.9; buf = lp(buf, 800 + 6000 * bright)
    y = np.zeros(n); damp = 0.996 - 0.006 * (1 - bright)
    for i in range(n):
        y[i] = buf[i % p]; buf[i % p] = damp * 0.5 * (buf[i % p] + buf[(i + 1) % p])
    return y * env(n, 0.002, dur, 3.5)

def bell(note, dur=2.5, ratio=3.5, idx=1.2):
    f = hz(note); n = int(dur * SR); t = np.arange(n) / SR
    mod = idx * np.exp(-t * 3) * np.sin(2 * np.pi * f * ratio * t)
    y = np.sin(2 * np.pi * f * t + mod) * env(n, 0.003, dur, 4.5)
    y += 0.25 * np.sin(2 * np.pi * f * 2.01 * t) * env(n, 0.002, dur * 0.4, 5)
    return y

def thud(f0=70, dur=0.6, drop=1.8):
    n = int(dur * SR); t = np.arange(n) / SR
    ph = 2 * np.pi * np.cumsum(f0 * (1 + drop * np.exp(-t * 28))) / SR
    y = np.sin(ph) * env(n, 0.002, dur, 6)
    click = lp(rng.standard_normal(n), 2500) * env(n, 0.0005, 0.012, 1)
    return y + 0.25 * click

def tick(f=1800, dur=0.05, noise=0.5):
    n = int(dur * SR); t = np.arange(n) / SR
    y = (1 - noise) * np.sin(2 * np.pi * f * t) + noise * bp(rng.standard_normal(n), f * 0.6, min(f * 2.2, 20000))
    return y * env(n, 0.0005, dur, 7)

def whoosh(dur, f0=300, f1=4000, pan0=0.0, pan1=0.0, shape='swell'):
    n = int(dur * SR); t = np.linspace(0, 1, n)
    x = rng.standard_normal(n)
    # time-varying bandpass via short blocks
    out = np.zeros(n); blk = 1024
    for i in range(0, n, blk):
        u = t[i]; fc = f0 * (f1 / f0) ** u
        seg = x[max(0, i - 2048): i + blk]
        y = bp(seg, max(40, fc * 0.5), min(20000, fc * 1.6))[-min(blk, n - i):]
        out[i:i + len(y)] = y
    if shape == 'swell': e = np.sin(np.pi * t) ** 1.6
    elif shape == 'rise': e = t ** 2.2 * (1 - np.clip((t - 0.97) / 0.03, 0, 1))
    else: e = (1 - t) ** 2
    out *= e
    pan = pan0 + (pan1 - pan0) * t
    return np.stack([out * np.cos((pan + 1) * np.pi / 4), out * np.sin((pan + 1) * np.pi / 4)], 1) * np.sqrt(2)

def sub(note, dur, att=0.02, rel=0.8):
    f = hz(note); n = int((dur + rel) * SR); t = np.arange(n) / SR
    y = np.sin(2 * np.pi * f * t) + 0.15 * np.sin(2 * np.pi * 2 * f * t)
    e = np.minimum(1, t / att) * np.clip((dur + rel - t) / rel, 0, 1)
    return y * e

# ---------------- score ----------------
BEAT = 60 / C['bpm']; S16 = BEAT / 4; D0 = C['musicDownbeat']; BAR = BEAT * 4

# Act 1 — the cream world: airy Amaj9 pad, unhurried
put(pad(['A3', 'E4', 'G#4', 'B4', 'C#5'], 7.3, att=2.2, rel=1.6, bright=2600), 0.0, 0.20, send=0.6)
put(pad(['E5', 'B5'], 6.0, att=3.0, rel=1.2, bright=5000), 0.8, 0.10, send=0.8)
# caption shimmers
put(bell('C#6', 2.5, 2.0, 0.5), C['captionA'][0], 0.07, pan=-0.3, send=0.9)
put(bell('E6', 2.0, 2.0, 0.5), C['captionA'][0] + 0.3, 0.04, pan=0.3, send=0.9)
put(bell('B5', 2.5, 2.0, 0.5), C['captionB'][0], 0.07, pan=0.2, send=0.9)
# layers separate: three soft wooden steps, descending
for t, nt, pn in zip(C['layersSplit'], ['E3', 'C#3', 'A2'], [-0.25, 0.0, 0.25]):
    put(thud(hz(nt), 0.7, 0.6), t, 0.32, pan=pn, send=0.4)
    put(pluck(nt.replace('3', '5').replace('2', '4'), 1.2, 0.35), t, 0.10, pan=pn, send=0.6)
    put(whoosh(0.7, 200, 1200, pn, pn, 'decay'), t, 0.05, send=0.3)

# Act 2 — the scan: riser, slanted sweep panning L->R, ignition
r0, r1 = C['riser']; put(whoosh(r1 - r0 + 0.05, 150, 5000, 0, 0, 'rise'), r0, 0.16, send=0.5)
s0, s1 = C['sweep']
put(whoosh(s1 - s0 + 0.2, 2500, 700, -0.9, 0.9, 'swell'), s0, 0.26, send=0.5)
put(sub('A1', s1 - s0, att=0.25, rel=1.0), s0, 0.30, send=0.1)
put(pad(['F#3', 'A3', 'C#4', 'E4', 'G#4'], 3.3, att=0.6, rel=1.4, bright=1500), s0, 0.36, send=0.6)
ig = C['ignite']
for k, (nt, pn) in enumerate([('B5', -0.2), ('E6', 0.15), ('G#6', 0.35), ('C#7', -0.1)]):
    put(bell(nt, 3.0, 3.5, 1.0), ig + k * 0.045, 0.11 - k * 0.015, pan=pn, send=0.8)
put(tick(5200, 0.06, 0.8), ig - 0.02, 0.08, send=0.6)
# lift: soft glide up
l0, l1 = C['lift']; n = int((l1 - l0) * SR); tt = np.arange(n) / SR
f = hz('E5') * 2 ** (np.clip(tt / (l1 - l0), 0, 1) ** 2 * 7 / 12)
put(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * tt / (l1 - l0)) ** 2, l0, 0.05, send=0.9)
put(whoosh(l1 - l0, 400, 2000, 0, 0, 'swell'), l0, 0.06, send=0.6)

# Act 3 — Guard: pulse at 100 BPM from the title downbeat
put(thud(46, 1.4, 1.2), D0, 0.62, send=0.2)
put(whoosh(0.9, 6000, 300, 0, 0, 'decay'), D0, 0.08, send=0.6)
put(bell('A5', 3.5, 1.0, 0.6), D0, 0.10, send=0.9); put(bell('E6', 3.0, 1.0, 0.4), D0 + 0.02, 0.06, pan=0.3, send=0.9)
prog = [  # (start, chord tones for arp, bass, pad)
    (D0,           ['D4', 'F#4', 'A4', 'C#5', 'E5', 'A4'], 'D2', ['D3', 'A3', 'C#4', 'E4', 'F#4']),
    (D0 + BAR,     ['F#4', 'A4', 'C#5', 'E5', 'G#5', 'C#5'], 'F#2', ['F#3', 'A3', 'C#4', 'E4', 'G#4']),
    (D0 + 2 * BAR, ['D4', 'F#4', 'A4', 'C#5', 'E5', 'A4'], 'D2', ['D3', 'A3', 'C#4', 'E4', 'F#4']),
    (D0 + 3 * BAR, ['E4', 'A4', 'B4', 'E5', 'F#5', 'B4'], 'E2', ['E3', 'B3', 'D4', 'F#4', 'A4']),
    (D0 + 4 * BAR, ['C#4', 'E4', 'A4', 'B4', 'E5', 'A4'], 'C#2', ['C#3', 'G#3', 'B3', 'E4']),
]
end_hit = C['logoHit']
order = [0, 2, 4, 1, 3, 5, 2, 4]
for bi, (st, arp, bass, pd) in enumerate(prog):
    bar_end = min(st + BAR, end_hit)
    if st >= end_hit: break
    put(pad(pd, bar_end - st, att=0.3, rel=0.9, bright=1400 + 300 * bi), st, 0.11, send=0.5)
    put(sub(bass, bar_end - st - 0.05, att=0.05, rel=0.3), st, 0.20, send=0.05)
    k = 0; t = st
    while t < bar_end - 0.01:
        step = int(round((t - D0) / S16))
        if bi == 0 and t < D0 + BEAT * 2: t += S16; k += 1; continue   # let the title breathe
        nt = arp[order[k % 8]]
        acc = 1.0 if step % 4 == 0 else 0.62
        bright = 0.35 + 0.12 * bi
        put(pluck(nt, 0.7, bright), t, 0.085 * acc, pan=0.35 * np.sin(step * 0.9), send=0.35)
        k += 1; t += S16
    # heartbeat kick on 1 and 3, quiet tick on offbeats from bar 3
    for b in range(4):
        tb = st + b * BEAT
        if tb >= end_hit - 0.05: break
        if bi >= 1 and b in (0, 2): put(thud(52, 0.45, 2.2), tb, 0.30, send=0.05)
        if bi >= 2: put(hp(tick(9000, 0.03, 1.0), 6000), tb + BEAT / 2, 0.035, pan=0.25, send=0.2)

# lockup + terminal entrance
put(whoosh(0.8, 3000, 600, 0.2, -0.6, 'swell'), C['titleToLockup'][0], 0.07, send=0.5)
put(whoosh(0.9, 500, 2500, 0.2, 0.6, 'swell'), 12.3, 0.07, send=0.5)

# terminal: key ticks, line blips, finding accents (panned toward the terminal on the right)
for key in ('scanType', 'stampType', 'verifyType'):
    a, b = C[key]; cmd = {'scanType': 'nation-guard scan', 'stampType': 'nation-guard baseline', 'verifyType': 'nation-guard verify'}[key]
    for i in range(len(cmd)):
        t = a + (b - a) * (i + 1) / len(cmd)
        put(tick(2200 + rng.uniform(-400, 600), 0.025, 0.85), t, 0.045 * rng.uniform(0.7, 1.0), pan=0.45, send=0.15)
    put(tick(1400, 0.04, 0.6), b + 0.12, 0.06, pan=0.45, send=0.2)  # enter
for key in ('scanLines', 'stampLines', 'verifyLines'):
    for t in C[key]: put(tick(3200, 0.03, 0.2), t, 0.025, pan=0.5, send=0.3)
for t, nt in zip(C['scanAccents'], ['E6', 'C#6']):
    put(bell(nt, 1.6, 3.0, 0.9), t, 0.09, pan=0.4, send=0.7)
for t, nt in zip(C['verifyAccents'], ['C#6', 'B5', 'A5']):
    put(bell(nt, 1.4, 3.0, 0.9), t, 0.075, pan=0.4, send=0.7)
c0, c1 = C['connector']; put(whoosh(0.7, 1500, 6000, -0.4, 0.4, 'swell'), c0, 0.05, send=0.7)
put(bell('A6', 1.2, 2.0, 0.4), c0 + 0.55, 0.05, pan=0.4, send=0.8)

# integrity: four baseline stamps, then the drift
for k, t in enumerate(C['stamps']):
    put(tick(900 + 140 * k, 0.07, 0.15), t, 0.10, pan=-0.4, send=0.4)
cs = C['cardShift']
put(thud(98, 0.5, 0.5), cs, 0.34, pan=-0.3, send=0.3)
n = int(0.6 * SR); tt = np.arange(n) / SR
put((np.sin(2 * np.pi * hz('A#4') * tt) + np.sin(2 * np.pi * hz('A4') * 1.003 * tt)) * env(n, 0.01, 0.6, 5), cs + 0.03, 0.05, pan=-0.3, send=0.6)
put(whoosh(0.6, 3000, 300, -0.2, -0.4, 'decay'), C['cardNew'] - 0.15, 0.09, send=0.4)
put(thud(80, 0.5, 1.0), C['cardNew'] + 0.35, 0.26, pan=-0.4, send=0.3)

# Act 4 — ending: reverse swell into the logo, resolve on Amaj9, long tail
o = C['outro']
put(whoosh(end_hit - o + 0.02, 200, 7000, 0, 0, 'rise'), o, 0.16, send=0.6)
put(thud(41, 2.6, 0.9), end_hit, 0.62, send=0.25)
put(sub('A1', 2.4, att=0.01, rel=1.6), end_hit, 0.26, send=0.05)
put(pad(['A2', 'E3', 'G#3', 'B3', 'C#4', 'E4'], 2.6, att=0.04, rel=1.4, bright=2200), end_hit, 0.45, send=0.7)
for k, (nt, pn) in enumerate([('A5', 0), ('C#6', -0.25), ('E6', 0.25), ('G#6', -0.1), ('B6', 0.15)]):
    put(bell(nt, 4.0, 2.0 + 0.5 * k, 0.8), end_hit + k * 0.06, 0.09 - 0.01 * k, pan=pn, send=0.9)
for t, nt in zip(C['endText'], ['E6', 'C#6', 'A5']):
    put(bell(nt, 1.6, 2.0, 0.3), t, 0.03, pan=0.1, send=0.9)

# ---------------- mix ----------------
def reverb_ir(sec=3.2, decay=3.0):
    n = int(sec * SR); t = np.arange(n) / SR
    ir = np.stack([rng.standard_normal(n), rng.standard_normal(n)], 1) * np.exp(-decay * t)[:, None]
    ir = lp(ir, 6500); ir[: int(0.012 * SR)] *= np.linspace(0, 1, int(0.012 * SR))[:, None]
    return ir / np.sqrt((ir ** 2).sum(0))
ir = reverb_ir()
rev = np.stack([fftconvolve(hp(wet[:, i], 180), ir[:, i])[:N] for i in range(2)], 1)
mix = dry + rev * 0.55
mix = hp(mix, 28)
# gentle master fade: in from silence, out at the very end
t = np.arange(N) / SR
mix *= np.clip(t / 0.25, 0, 1)[:, None] * np.clip((DUR - t) / 1.4, 0, 1)[:, None] ** 1.3
# soft clip + normalise
mix = np.tanh(mix * 0.9) / np.tanh(0.9)
mix *= 0.89 / np.abs(mix).max()
import wave, os
os.makedirs('out', exist_ok=True)
pcm = (mix * 32767).astype('<i2')
with wave.open('out/audio.wav', 'wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
print('wrote out/audio.wav', mix.shape, 'peak', np.abs(mix).max())
