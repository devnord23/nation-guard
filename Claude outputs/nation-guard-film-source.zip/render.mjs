// Usage: node render.mjs stills 0,2.5,5  -> stills/*.png
//        node render.mjs video [fps] [start] [end] -> frames piped to ffmpeg (out/picture.mp4)
import { chromium } from 'playwright-core';
import { spawn } from 'child_process';
import fs from 'fs';
const [mode='stills', arg='0', a2, a3] = process.argv.slice(2);
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--force-color-profile=srgb','--disable-lcd-text','--font-render-hinting=none','--ignore-gpu-blocklist','--enable-gpu-rasterization'] });
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
page.on('console', m => console.log('[page]', m.text()));
page.on('pageerror', e => console.log('[err]', e.message));
await page.goto('file://' + process.cwd() + '/index.html');
await page.evaluate(() => window.ready);
const shot = async t => { await page.evaluate(t => window.render(t), t); return page.screenshot({ type: 'jpeg', quality: 95 }); };
if (mode === 'stills') {
  fs.mkdirSync('stills', { recursive: true });
  for (const t of arg.split(',').map(Number)) fs.writeFileSync(`stills/t${t.toFixed(2)}.jpg`, await shot(t));
} else {
  const fps = +(arg || 30), start = +(a2 || 0), end = +(a3 || 25);
  fs.mkdirSync('out', { recursive: true });
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-',
    '-c:v', 'libx264', '-preset', 'slow', '-crf', '14', '-pix_fmt', 'yuv420p', '-r', String(fps), `out/picture_${start}_${end}.mp4`], { stdio: ['pipe', 'inherit', 'inherit'] });
  const n = Math.round((end - start) * fps); const t0 = Date.now();
  for (let i = 0; i < n; i++) {
    const buf = await shot(start + i / fps);
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    if (i % 60 === 0) console.log(`frame ${i}/${n}  ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  }
  ff.stdin.end(); await new Promise(r => ff.on('close', r));
}
await browser.close();
